<?php
   $title = "Homepage";

   // here we'll just display our view file
   // remember the "view.php" is just a convention
   // you can name it whatever you'd like

   require '../src/views/index.view.php';

