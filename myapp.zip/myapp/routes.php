<?php

// This is our homepage route,
$router->get('/', 'controllers/index.php');

$router->get('/about', 'controllers/about.php');
