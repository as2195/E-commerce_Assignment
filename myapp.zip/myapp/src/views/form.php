<?php
$title = "Thank You";
    if(isset($_POST['submit'])){
//        echo '<h2>Submited information<h2/>';
        date_default_timezone_set("EST"); 
        $date = date("Y-m-d H:i:s");
        $name=$_REQUEST['name'];
        $email=$_REQUEST['email_address'];
        $password=$_REQUEST['password'];
        
//        echo 'You submitted the form on: '.$date.'<br/>';
//        echo 'Your name is: '.$name.'<br/>';
//        echo 'Your email is: '.$email.'<br/>';
//        echo 'Your password is: '.$password.'<br/>';
        
        
        
    }
?>

<!doctype html> <!-- this is setting our HTML document as an HTML5 document...this is VERY important -->
<html lang="en">
    <head>
        
      <?php require 'parts/html_header.partial.php'; ?>
        
<!--        <script src="../src/views/form_validation.js"></script>-->
    </head>
    <body>
        
        <div onload="../src/views/thank.your.php" class="container">
           <h2>Thank you</h2>
        <p>Thank you very much for submiting this form.  Your answer is very appreciated.</p>
            <table class="table table-striped">
                     <thead>
                        <tr>
                           <th>ID</th>
                           <th>Name</th>
                           <th>Email</th>
                            <th>Password</th>
                        </tr>
                     </thead>
                     <tbody>
                           <tr>
                              <td><?=$date?></td>
                              <td><?=$name?></td>
                              <td><?=$email ?></td>
                               <td><?=$password?></td>
                           </tr>
                     </tbody>
                 </table>
        </div>
    </body>
</html>