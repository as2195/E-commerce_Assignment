<!doctype html> <!-- this is setting our HTML document as an HTML5 document...this is VERY important -->
<html lang="en">
    <head>
      <?php require 'parts/html_header.partial.php'; ?>
    </head>
    <body>
        <h2>Thank you</h2>
        <p>Thank you very much for submiting this form.  Your answer is very appreciated.</p>
        <a href="../src/views/index.view.php">Back to previous page</a>
    </body>
</html>