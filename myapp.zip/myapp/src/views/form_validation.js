function valid_check(){
    var name =  document.getElementById('name');
	var email =  document.getElementById('email_address');
	var password =  document.getElementById('password');
	
	if(name.value.length==0){
	    document.getElementById('head').innerText="* All fields are required *";
	    firstname.focus();
	    return false;
	}
	
	if(name_check(name, "*For name only use alphabetic characters")){
	    if(email_check(email, "*Write a valid email address")){
	        if(password_check(password, "*Write a password")){
                return true;
	            }
	        }
	    }
	}
	
	return false;
	
}

function name_check(inputtext, alertMsg, num){
    var pattern=/^([A-Z]{1})[a-z]{1,10}\ ([A-Z]{1})[a-z]{1,10}$/;
    if(inputtext.value.match(pattern)){
        return true;
    }else{
        document.getElementById('p1').innerText=alertMsg;
        inputtext.focus();
        return false;
    }
}

function email_check(inputtext, alertMsg){
    var pattern= /^[\w\-\.]{1,20}\@[A-Za-z0-9\-]{1,20}\.[A-Za-z]{2,4}$/;
    if(inputtext.value.match(pattern)){
        return true;
    }else{
        document.getElementById('p2').innerText=alertMsg;
        inputtext.focus();
        return false;
    }
}

function password_check(inputtext, alertMsg){
    var pattern= /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/;
    if(inputtext.value.match(pattern)){
        return true;
    }else{
        document.getElementById('p3').innerText=alertMsg;
        inputtext.focus();
        return false;
    }
}