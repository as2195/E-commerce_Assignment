<!doctype html> <!-- this is setting our HTML document as an HTML5 document...this is VERY important -->
<html lang="en">
    <head>
      <?php require 'parts/html_header.partial.php'; ?>
<!--        <script src="../src/views/form_validation.js"></script>-->
    </head>
    <body>
        
        <div class="container">
           <h1>Sign Up</h1>
            
           <form onsubmit='return valid_check()' class="form-group" id="sign_up"  action="../src/views/form.php" method="post">
               <br><p id="head"></p><br>
               <!-- Code for name-->
               <div class="form-group">
                   <label for="name" class="form-group d-block">
                    Full name:
                    <input type="text" name="name" id="name" class="form-control" placeholder="First and Last name" required>
                </label>
               <p id="p1"></p>
               </div>

               <!--Code for email-->
               <div class="form-group">
                   <label for="email_address" class="form-group d-block">
                    Email:
                    <input type="email" name="email_address" id="email_address" class="form-control" placeholder="example@place.com" required email>
                </label>
               <p id="p2"></p>
               </div>
               
               <!--Code for password-->
               <div class="form-group">
                   <label for="password" class="form-group d-block">
                    Password:
                    <input type="password" name="password" id="password" class="form-control" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required>
                </label>
               <p id="p3"></p>
               </div>
               
               <!--Code for Submit button-->
                <div class="form-group">
                    <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                </div>
<!--               <a href="../src/views/thank.your.php">View thank you note</a>-->
           </form>
        </div>
    </body>
</html>