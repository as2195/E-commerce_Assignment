        <meta charset="utf-8"> <!-- set the charset so you can accept and work with many different types of keyboards and in many different countries -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> <!-- Important for a responsive site -->

        <title><?=$title; ?></title> <!-- We're loading this variable in the controllers, but what happens if you forget to set it? -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css"> <!-- loading up our CSS, in this case we're pulling in the CSS from the Bootstrap CDN (Content Delivery Network) -->
        <script src="../src/views/form_validation.js"></script>